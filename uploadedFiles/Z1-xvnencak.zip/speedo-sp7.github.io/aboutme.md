---
layout: aboutme
title: O mne
description: Rád Ťa spoznávam! Chcel by si ma spoznať bližšie? Tu si na správnom mieste, čekuj obsah nižšie!
day_quote: Ako by som začal? Som mladý, šikovný, ale hlavne skromný...
           Momentálne študujem na Fakulte informatiky a informačný technológií na STU v Bratislave, stále ma živia rodičia,
           takže ak by si odo mňa chcel akúkoľvek podporu, veľmi rád Ti pomôžem, ale peniaze si pýtaj od mamky.
---

# Ako som sa narodil

Asi začnem zhurta ale narodil som sa v aute :car:. Viem, je to nezvyčajné, ale moja mamka s tatkom to akosi nestihli. Narodil som sa 3. Novembra 1994,
takže ak dokážeš rátať, momentálne mám 22 rokov. Celý život som vyrastal v malej dedinke s menom Vlková. Neviem prečp práve Vlková,
kedže som u nás vlka nikdy nestretol, ale tak nesťažujem sa... :smile:

# Kde som študoval

Celý môj život študujem. Nie žeby ma to bavilo, ale proste musím. Nemôžem totiž ostať hlúpy, aj keď mnohokrát počujem, že hlúpym patrí svet, ja chcem byť výnimka. Keďže som vyrastal na dedine, ako malý som navštevoval dedinskú školu v susednej dedinke Vrbov, ktorá mi ale dala skvelý základ a som veľmi šťastný, že ma práve táto škola vychovala.  

Táto škola mi dala skvelý základ vo všetkých smeroch, a tak som ďalej študoval na gymnáziu P. O. Hviezdoslava v Kežmarku. Odtiaľ pokračovala moja ďalšia cesta, z dedinky Vlková rovno do hlavného mesta, Bratislavy :smile:.

# A čo robím momentálne?

Píšem, programujem, učím sa. Nie veľa ľudí malo v živote to šťastie, že im bolo umožnené robiť to, čo v živote chceli. Ja som to šťastie mal. Už ako malého chlapca ma zaujímali počitače, pamätám si ako nám rodičia kúpili domov počítač, mal som asi 4 roky, bol to v tom čase úžasný Windows 95 :smile:. Neviem, čo presne ma presvedčilo, aby som išiel na Fakultu informatiky a informačných technológií do Bratislavy, ale pravdepodobne to bola nechuť učit sa veľa teórie, nakoľko radšej na veci prichádzam sám. No hoc, aj majster tesár sa sem tam utne...  

Ak by si si chcel pozrieť nejakú moju tvorbu alebo projekty na ktorých pracujem, pozri si moje [PORTFÓLIO](/portfolio), možno ťa niečo zaujme :smile:.
