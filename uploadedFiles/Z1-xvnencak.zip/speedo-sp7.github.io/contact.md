---
layout: contact
title: Kontaktuj ma!
description: Stále nemáš dosť? Tak mi napíš, zavolaj, príď... ;)

contact_comment: Síce neodpovedám, tvoju správu som dostal a raz odpoviem, len momentálne asi nemám čas ;) Na sprácu Ti veľmi rád odpoviem hneď ako budem môcť.
---

## Nájdeš ma aj na sociálnych sieťach

Ako mnoho mladých ľudí ani ja nie som žiadne Béčko a aj mňa nájdeš na mnohých sociálnych sieťach. Linky na moje profily sú uvedené nižšie :smile:
